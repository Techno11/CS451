================================
A4 (Final Project): Virtual Memory Manager
README.txt
By: Brendan Sting, Soren Zaiser
================================

Main Description - Virtual memory Manager

All features are implimented and working


TO RUN:

1. Compile the program
    gcc main.c

2. Ensure a file "PROCESS.txt" and "addresses.txt" exist in the same directory of the compiled executable.  File names are case sensitive!

3. Run the program
    ./a.out
